# LOAN PREDICTION MODEL

This is a model which predicts whether a loan will be approved or not. This model uses 3 supervised learning algorithms and compares which works best.The algorithms used are Logistic Regression,Descision Tree Classifer and RandomForest Classifier.
